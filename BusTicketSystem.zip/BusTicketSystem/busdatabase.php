<?php //busdatabase.php

	$datab_mysql="bus_database"; //the name of database

	//connect and select the database that created
	$store = mysqli_connect("localhost","root","") or die
		//Print error message
		("Sorry...Could not select database.");
		
	mysqli_select_db($store, $datab_mysql) or die
		//Print error message
		("Sorry..You didn't select the database.");
	
?>
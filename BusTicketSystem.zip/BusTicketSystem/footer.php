			<!-- Start Callaction Area -->
			<?php
				echo "<section class='callaction-area relative section-gap'>";
					echo "<div class='overlay overlay-bg'></div>";
					echo "<div class='container'>";
						echo "<div class='row justify-content-center'>";
							echo "<div class='col-lg-10'>";
								echo "<h1 class='text-white'>Experience Great Support</h1>";
								echo "<p>
									We respond to every inquiry within 1 to 2 working days.
								</p>";
								//Contact Us button
								echo "<a class='callaction-btn text-uppercase' href='contact.php'>Contact Us</a>";	
							echo "</div>";
						echo "</div>";
					echo "</div>";	
				echo "</section>";
			?>
			<!-- End Callaction Area -->
			
			<!-- Start Footer Area -->		
			<?php	
				echo "<footer class='footer-area section-gap'>";
					echo "<div class='container'>";
						echo "<div class='row'>";
							echo "<div class='col-lg-2 col-md-6 col-sm-6'>";
							echo "</div>";
							echo "<div class='col-lg-2 col-md-6 col-sm-6'>";
								echo "<div class='single-footer-widget'>";
									echo "<h6>Features</h6>";
									echo "<ul>";
										echo "<li><a href='contact.php'>Contact Us</a></li>";
										echo "<li><a href='jobvacancies.php'>Job Vacancies</a></li>";
									echo "</ul>";								
								echo "</div>";
							echo "</div>";
							echo "<div class='col-lg-2 col-md-6 col-sm-6'>";
							echo "</div>";							
							echo "<div class='col-lg-2 col-md-6 col-sm-6 social-widget'>";
								echo "<div class='single-footer-widget'>";
									echo "<h6>Follow Us</h6>";
									echo "<p>Let us be social</p>";
									echo "<div class='footer-social d-flex align-items-center'>";
										echo "<a href='#'><i class='fa fa-facebook'></i></a>";
										echo "<a href='#'><i class='fa fa-twitter'></i></a>";
										echo "<a href='#'><i class='fa fa-dribbble'></i></a>";
										echo "<a href='#'><i class='fa fa-behance'></i></a>";
									echo "</div>";
								echo "</div>";
							echo "</div>";						
							echo "<div class='col-lg-4  col-md-6 col-sm-6'>";
								echo "<div class='single-footer-widget'>";
									echo "<h6>Newsletter</h6>";
									echo "<p>Stay update with our latest</p>";
									echo "<div class='' id='mc_embed_signup'>";
										echo "<form target='_blank' novalidate='true' action='https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01' method='get' class='form-inline'>";
											echo "<input class='form-control' name='EMAIL' placeholder='Enter Email' onfocus='this.placeholder = ''' onblur='this.placeholder = 'Enter Email '' required='' type='email'>";
												echo "<button class='click-btn btn btn-default'><span class='lnr lnr-arrow-right'></span></button>";
												echo "<div style='position: absolute; left: -5000px;'>";
													echo "<input name='b_36c4fd991d266f23781ded980_aefe40901a' tabindex='-1' value='' type='text'>";
												echo "</div>";

											echo "<div class='info'></div>";
										echo "</form>";
									echo "</div>";
								echo "</div>";
							echo "</div>";	
							echo "<p class='mt-50 mx-auto footer-text col-lg-12'>
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
	Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class='fa fa-heart-o' aria-hidden='true'></i> by <a href='https://colorlib.com' target='_blank'>Colorlib</a>
	<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
							</p>";										
						echo "</div>";
					echo "</div>";
				echo "</footer>";
			?>
			<!-- End Footer Area -->		
			<?php
				echo "<script src='js/vendor/jquery-2.2.4.min.js'></script>";
				echo "<script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js' integrity='sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q' crossorigin='anonymous'></script>";
				echo "<script src='js/vendor/bootstrap.min.js'></script>";			
				echo "<script type='text/javascript' src='https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA'></script>";
				echo "<script src='https://code.jquery.com/ui/1.12.1/jquery-ui.js'></script>";			
				echo "<script src='js/easing.min.js'></script>";			
				echo "<script src='js/hoverIntent.js'></script>";
				echo "<script src='js/superfish.min.js'></script>";	
				echo "<script src='js/jquery.ajaxchimp.min.js'></script>";
				echo "<script src='js/jquery.magnific-popup.min.js'></script>";	
				echo "<script src='js/owl.carousel.min.js'></script>";			
				echo "<script src='js/jquery.sticky.js'></script>";
				echo "<script src='js/jquery.nice-select.min.js'></script>";	
				echo "<script src='js/waypoints.min.js'></script>";
				echo "<script src='js/jquery.counterup.min.js'></script>";					
				echo "<script src='js/parallax.min.js'></script>";		
				echo "<script src='js/mail-script.js'></script>";
				echo "<script src='js/main.js'></script>";
			?>
		</body>
	</html>